import template
import model

model.create_db()
template.app()
